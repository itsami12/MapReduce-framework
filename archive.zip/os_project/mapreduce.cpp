#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <pthread.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

using namespace std;

// Define the maximum number of threads per child process
#define MAX_THREADS 4

// Define the maximum number of words per chunk (for simplicity)
#define MAX_WORDS 1000

// Structure to hold key-value pairs
struct KeyValue {
    string key;
    int value;
    KeyValue* next;
};

// Structure to pass data to threads
struct ThreadData {
    string data;
    struct KeyValueList* kv_head;  // Changed from KeyValue* to KeyValueList*
    pthread_mutex_t* mutex;
};

// Linked list to store key-value pairs
struct KeyValueList {
    KeyValue* head;
};

// Mutex for synchronization in threads
pthread_mutex_t thread_mutex;

// Function to add a key-value pair to the linked list
void add_key_value(KeyValueList* list, const string& key, int value) {
    KeyValue* new_kv = new KeyValue();
    new_kv->key = key;
    new_kv->value = value;
    new_kv->next = nullptr;

    if (list->head == nullptr) {
        list->head = new_kv;
    } else {
        KeyValue* temp = list->head;
        while (temp->next != nullptr) {
            temp = temp->next;
        }
        temp->next = new_kv;
    }
}

// Function to split a string into words
int split_words(const string &str, char words[][50]) {
    stringstream ss(str);
    string word;
    int count = 0;
    while (ss >> word && count < MAX_WORDS) {
        strncpy(words[count], word.c_str(), 49);
        words[count][49] = '\0'; // Ensure null-termination
        count++;
    }
    return count;
}

// Thread function to perform map operation
void* map_thread(void* arg) {
    ThreadData* thread_data = (ThreadData*)arg;
    char words[MAX_WORDS][50];
    int word_count = split_words(thread_data->data, words);

    for (int i = 0; i < word_count; ++i) {
        pthread_mutex_lock(thread_data->mutex);
        add_key_value(thread_data->kv_head, words[i], 1);
        pthread_mutex_unlock(thread_data->mutex);
    }

    pthread_exit(0);
}

// Function to perform the map operation in child process
KeyValueList* map_function(const string& data) {
    KeyValueList* kv_list = new KeyValueList();
    kv_list->head = nullptr;

    pthread_t threads[MAX_THREADS];
    ThreadData thread_data[MAX_THREADS];
    pthread_mutex_init(&thread_mutex, nullptr);

    // Split data into chunks for threads (simple split by words)
    // For simplicity, each thread processes approximately equal number of words
    char words[MAX_WORDS][50];
    int total_words = split_words(data, words);
    int words_per_thread = (total_words + MAX_THREADS - 1) / MAX_THREADS;

    for (int i = 0; i < MAX_THREADS; ++i) {
        int start = i * words_per_thread;
        if (start >= total_words) {
            thread_data[i].data = "";
        } else {
            int end = (i + 1) * words_per_thread;
            if (end > total_words) end = total_words;
            stringstream ss;
            for (int j = start; j < end; ++j) {
                ss << words[j] << " ";
            }
            thread_data[i].data = ss.str();
        }
        thread_data[i].kv_head = kv_list;  // Correct assignment without casting
        thread_data[i].mutex = &thread_mutex;
        pthread_create(&threads[i], nullptr, map_thread, (void*)&thread_data[i]);
    }

    // Wait for all threads to finish
    for (int i = 0; i < MAX_THREADS; ++i) {
        pthread_join(threads[i], nullptr);
    }

    pthread_mutex_destroy(&thread_mutex);
    return kv_list;
}

// Function to serialize key-value pairs into a string
string serialize_kv(KeyValue* head) {
    stringstream ss;
    KeyValue* current = head;
    while (current != nullptr) {
        ss << current->key << ":" << current->value << " ";
        current = current->next;
    }
    return ss.str();
}

// Function to deserialize key-value pairs from a string
KeyValue* deserialize_kv(const string& data) {
    KeyValue* head = nullptr;
    KeyValue* tail = nullptr;
    stringstream ss(data);
    string pair;
    while (ss >> pair) {
        size_t delim = pair.find(':');
        if (delim != string::npos) {
            string key = pair.substr(0, delim);
            int value = atoi(pair.substr(delim + 1).c_str());

            KeyValue* new_kv = new KeyValue();
            new_kv->key = key;
            new_kv->value = value;
            new_kv->next = nullptr;

            if (head == nullptr) {
                head = new_kv;
                tail = new_kv;
            } else {
                tail->next = new_kv;
                tail = new_kv;
            }
        }
    }
    return head;
}

// Function to perform the reduce operation
void reduce_function(KeyValueList* combined_list) {
    // Simple aggregation using linked list
    KeyValue* current = combined_list->head;
    KeyValueList* final_list = new KeyValueList();
    final_list->head = nullptr;

    while (current != nullptr) {
        // Check if key already exists in final_list
        KeyValue* search = final_list->head;
        bool found = false;
        while (search != nullptr) {
            if (search->key == current->key) {
                search->value += current->value;
                found = true;
                break;
            }
            search = search->next;
        }
        if (!found) {
            add_key_value(final_list, current->key, current->value);
        }
        current = current->next;
    }

    // Print the final aggregated results
    KeyValue* result = final_list->head;
    while (result != nullptr) {
        cout << "(" << result->key << ", " << result->value << ")\n";
        result = result->next;
    }

    // Cleanup
    // (In a real application, you'd also free the allocated memory)
}

int main(int argc, char* argv[]) {
    string inputFile = "input1.txt";  // Default input file path
    if (argc > 1) {
        inputFile = argv[1];
    }

    ifstream input(inputFile);
    if (!input.is_open()) {
        cerr << "Failed to open the input file: " << inputFile << "\n";
        return 1;
    }

    // Create a pipe for IPC
    int pipefd[2];
    if (pipe(pipefd) == -1) {
        cerr << "Pipe creation failed.\n";
        return 1;
    }

    // Read the entire file content
    stringstream buffer;
    buffer << input.rdbuf();
    string input_data = buffer.str();

    // Split the input data into lines (for simplicity)
    stringstream ss(input_data);
    string line;
    const int NUM_CHILDREN = 4;  // Number of child processes
    int child_count = 0;

    while (getline(ss, line) && child_count < NUM_CHILDREN) {
        pid_t pid = fork();
        if (pid < 0) {
            cerr << "Fork failed.\n";
            return 1;
        } else if (pid == 0) {
            // Child process
            close(pipefd[0]);  // Close unused read end

            // Perform map operation
            KeyValueList* kv_list = map_function(line);

            // Serialize key-value pairs
            string serialized = serialize_kv(kv_list->head);

            // Write to pipe
            write(pipefd[1], serialized.c_str(), serialized.size());

            close(pipefd[1]);  // Close write end
            exit(0);
        } else {
            // Parent process
            child_count++;
        }
    }

    // Parent process
    close(pipefd[1]);  // Close unused write end

    // Wait for all child processes to finish
    for (int i = 0; i < child_count; ++i) {
        wait(NULL);
    }

    // Read from pipe and collect all key-value pairs
    char buffer_read[4096];
    ssize_t bytes_read;
    string all_kv_data;
    while ((bytes_read = read(pipefd[0], buffer_read, sizeof(buffer_read)-1)) > 0) {
        buffer_read[bytes_read] = '\0';
        all_kv_data += buffer_read;
    }
    close(pipefd[0]);  // Close read end

    // Deserialize all key-value pairs
    KeyValue* all_kv = deserialize_kv(all_kv_data);

    // Aggregate all key-value pairs
    KeyValueList* combined_list = new KeyValueList();
    combined_list->head = all_kv;

    // Perform reduce operation
    reduce_function(combined_list);

    // Cleanup
    // (In a real application, you'd also free the allocated memory)

    return 0;
}